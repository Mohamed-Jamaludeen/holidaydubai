import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Property from './pages/Property'
import ListProperty from './pages/ListProperty'

export default function App() {
  return (
    <div className="p-4">
      <nav className="flex gap-4 bg-gray-100 p-4 rounded mb-4">
        <Link to="/">Home</Link>
        <Link to="/list">List Your Property</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/property/:id" element={<Property />} />
        <Route path="/list" element={<ListProperty />} />
      </Routes>
    </div>
  )
}
